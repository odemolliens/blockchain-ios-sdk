//
//  ODResourcesManager.h
//  ODiSyFramework
//
//  Created by Olivier Demolliens on 14/03/2014.
//  Copyright (c) 2014 Google. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ODResourcesManager : NSObject
{
    
}

+ (UIImage *)imageWithName:(NSString*)ressourceName;

@end
